import logging
from typing import Any, Awaitable, Callable, Dict
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery

logger = logging.getLogger(__name__)

BANNED_TEXT = (
    "🚫 <b>Your account has been banned.</b>\n\n"
    "If you believe this is a mistake, please contact support."
)


class AuthMiddleware(BaseMiddleware):
    """Injects db + config into handler data and blocks banned users."""

    def __init__(self, db, config):
        self.db = db
        self.config = config
        super().__init__()

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        data["db"] = self.db
        data["config"] = self.config

        # Determine Telegram user
        tg_user = None
        if isinstance(event, Message):
            tg_user = event.from_user
        elif isinstance(event, CallbackQuery):
            tg_user = event.from_user

        if tg_user:
            user = await self.db.get_user(tg_user.id)
            if user and user.get("is_banned"):
                if isinstance(event, Message):
                    await event.answer(BANNED_TEXT, parse_mode="HTML")
                elif isinstance(event, CallbackQuery):
                    await event.answer("🚫 You are banned.", show_alert=True)
                return  # stop processing

        return await handler(event, data)
