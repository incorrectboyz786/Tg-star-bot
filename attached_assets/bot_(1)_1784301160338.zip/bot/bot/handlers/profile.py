import logging
from aiogram import Router, F
from aiogram.types import CallbackQuery

from database import Database
from keyboards.user_kb import back_to_menu_kb
from utils.helpers import escape_html, format_number

logger = logging.getLogger(__name__)
router = Router()


@router.callback_query(F.data == "profile")
async def cb_profile(cb: CallbackQuery, db: Database) -> None:
    await cb.answer()
    tg = cb.from_user
    user = await db.get_user(tg.id)
    if not user:
        await cb.answer("Please send /start first.", show_alert=True)
        return

    wallet = await db.get_wallet(user["id"])
    ref_count = await db.get_referral_count(user["id"])

    username = f"@{user['username']}" if user.get("username") else "—"
    last_name = user.get("last_name") or ""
    full_name = f"{user['first_name']} {last_name}".strip()

    # Format join date
    created_raw = user.get("created_at", "")
    created = created_raw[:10] if created_raw else "—"

    min_balance = int(await db.get_setting("min_premium_balance", "500"))
    verified_icon = "✅" if user.get("device_verified") else "❌"
    premium_ready = "⭐" if wallet.get("balance", 0) >= min_balance else "❌"

    text = (
        "👤 <b>Your Profile</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📛 <b>Name:</b> {escape_html(full_name)}\n"
        f"🔖 <b>Username:</b> {escape_html(username)}\n"
        f"🆔 <b>Telegram ID:</b> <code>{tg.id}</code>\n\n"
        f"💰 <b>Wallet Balance:</b> {format_number(wallet.get('balance', 0))} pts\n"
        f"👥 <b>Total Referrals:</b> {format_number(ref_count)}\n"
        f"📅 <b>Member Since:</b> {created}\n\n"
        f"🔐 <b>Device Verified:</b> {verified_icon}\n"
        f"{premium_ready} <b>Premium Status:</b> {'Ready to claim' if premium_ready == '⭐' else 'Keep earning!'}"
    )
    await cb.message.edit_text(text, parse_mode="HTML", reply_markup=back_to_menu_kb())
