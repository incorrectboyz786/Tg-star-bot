#!/bin/bash
# Telegram Bot startup script
set -e

BOT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="/root/bot_venv"

# Install / sync packages if venv missing
if [ ! -d "$VENV" ]; then
  echo "[bot] Creating virtual environment at /root/bot_venv..."
  python3 -m venv "$VENV"
  "$VENV/bin/pip" install -r "$BOT_DIR/requirements.txt"
fi

echo "[bot] Starting Telegram bot..."
cd "$BOT_DIR"
exec "$VENV/bin/python" main.py
