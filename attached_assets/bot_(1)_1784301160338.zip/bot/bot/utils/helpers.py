from datetime import timedelta
from typing import Optional


def format_timedelta(td: timedelta) -> str:
    """Human-readable countdown string."""
    total = int(td.total_seconds())
    if total <= 0:
        return "0s"
    hours, rem = divmod(total, 3600)
    minutes, seconds = divmod(rem, 60)
    parts = []
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if seconds or not parts:
        parts.append(f"{seconds}s")
    return " ".join(parts)


def format_number(n: int) -> str:
    """Format with commas, e.g. 1,234,567"""
    return f"{n:,}"


def mention(first_name: str, user_id: int) -> str:
    """HTML mention link."""
    safe = first_name.replace("<", "&lt;").replace(">", "&gt;")
    return f'<a href="tg://user?id={user_id}">{safe}</a>'


def escape_html(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def truncate(text: str, max_len: int = 30) -> str:
    return text if len(text) <= max_len else text[: max_len - 1] + "…"
